<?php
require_once('includes/init.php');

$user_role = get_role();
if($user_role == 'admin' || $user_role == 'user' || $user_role == 'manager' ) {
?>	

<html>
	<head>
		<title>Sistem Pendukung Keputusan Metode electre</title>
	<?php
    // Set timezone ke waktu lokal (contoh timezone untuk Jakarta)
    date_default_timezone_set('Asia/Jakarta');
    ?>
	</head>
<body onload="window.print();">

<div style="width:100%;margin:0 auto;text-align:center;">
	<h2>SMA NEGERI 13 SIJUNJUNG</h2>
	<h2>SUMATERA BARAT. INDONESIA</h2>
	<b>____________________________________________________________________________________________________</b>
	<h3>LAPORAN DATA SELEKSI OSN SMA NEGERI 13 SIJUNJUNG</h3>
	<h4>Generated <?php echo date('d/m/Y H:i:s'); ?></h4>
	<table width="100%" cellspacing="0" cellpadding="5" border="1">
    <thead>
        <tr align="center" style="background-color: #4e73df; color: black;">
            <th>NISN</th>
            <th>Nama Siswa</th>
            <th>Kelas</th>
            <th>Ranking</th>
            <th>Keterangan</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Ambil dan urutkan data berdasarkan nilai tertinggi
        $query = mysqli_query($koneksi, "
            SELECT 
                a.nama, 
                a.nisn, 
                a.kelas,  
                h.keputusan
            FROM hasil h
            JOIN alternatif a ON h.id_alternatif = a.id_alternatif
            ORDER BY h.nilai DESC
        ");

        $no = 1;
        while($data = mysqli_fetch_assoc($query)) {
            echo "<tr align='center'>";
            echo "<td>{$data['nisn']}</td>";
            echo "<td align='left'>{$data['nama']}</td>";
            echo "<td>{$data['kelas']}</td>";
            echo "<td>{$no}</td>";
            echo "<td>{$data['keputusan']}</td>";
            echo "</tr>";
            $no++;
        }
        ?>
    </tbody>
</table>

</div>
<br>
<?php
// Hitung total peserta
$query_total = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM hasil");
$data_total = mysqli_fetch_assoc($query_total);
$total_peserta = $data_total['total'];

// Ambil 4 siswa teratas yang lulus
$query_lulus = mysqli_query($koneksi, "
    SELECT a.nama 
    FROM hasil h 
    JOIN alternatif a ON h.id_alternatif = a.id_alternatif 
    WHERE h.keputusan = 'Lulus' 
    ORDER BY h.nilai DESC 
    LIMIT 4
");
$nama_lulus = [];
while ($row_lulus = mysqli_fetch_assoc($query_lulus)) {
    $nama_lulus[] = $row_lulus['nama'];
}

// Hitung jumlah lulus & tidak lulus
$total_lulus = count($nama_lulus);
$total_tidak_lulus = $total_peserta - $total_lulus;
?>

<p style="font-weight:bold; text-align:left; margin-left:0em;">
    Berdasarkan hasil perhitungan dan perangkingan akhir, 
    terdapat <span style="color:green;"><?= $total_lulus; ?> orang yang dinyatakan LULUS</span>, yaitu: 
    <?= implode(", ", $nama_lulus); ?>. 
    Sedangkan jumlah peserta yang <span style="color:red;">tidak lulus</span> adalah 
    <?= $total_tidak_lulus; ?> orang.
</p>

<p>
Nama siswa yang di sebutkan di atas memiliki potensi yang baik untuk menjadi kandidat dalam perwakilan OSN. 
Kami berharap siswa-siswa yang lulus dapat terus memberikan kontribusi positif bagi sekolah. 
<b>Selamat kepada para siswa yang bersangkutan!</b>
<br><br><br>
</p>

<div style="width:100%;margin:0 auto;text-align:right;">		
    <h4>SMA Negeri 13 Sijunjung </h4>
    <h4 style="margin-right: 3em;"><?php echo date('d/m/Y'); ?></h4>
    <h4 style="margin-right: 2em;">Kepala Sekolah</h4>	
    <br><br><br>
    <h4>(.........................................)</h4>
</div>

</body>
</html>

<?php
}
else {
	header('Location: login.php');
}
?>