<?php
require_once('includes/init.php');

// Periksa role pengguna
$user_role = get_role();
if ($user_role == 'admin' || $user_role == 'user' || $user_role == 'manager') {

    $page = "Hasil";
    require_once('template/header.php');

    // Proses Simpan Semua Keputusan
    if (isset($_POST['submit_all'])) {
        foreach ($_POST['keputusan'] as $id_alternatif => $keputusan) {
            $keputusan = mysqli_real_escape_string($koneksi, $keputusan);
            $id_alternatif = intval($id_alternatif);

            // Update keputusan untuk setiap alternatif
            $simpan = mysqli_query($koneksi, "UPDATE hasil SET keputusan = '$keputusan' WHERE id_alternatif = $id_alternatif");
        }

        if ($simpan) {
            echo "<script>alert('Semua keputusan berhasil disimpan!');</script>";
        } else {
            echo "<script>alert('Data gagal disimpan!');</script>";
        }
    }

    // Update otomatis 4 orang teratas menjadi "Lulus"
mysqli_query($koneksi, "UPDATE hasil SET keputusan = 'Tidak Lulus'"); // reset dulu
$query_top_4 = mysqli_query($koneksi, "SELECT id_alternatif FROM hasil ORDER BY nilai DESC LIMIT 4");
while ($row_top_4 = mysqli_fetch_assoc($query_top_4)) {
    $id_alternatif = intval($row_top_4['id_alternatif']);
    mysqli_query($koneksi, "UPDATE hasil SET keputusan = 'Lulus' WHERE id_alternatif = $id_alternatif");
}

// Hitung total peserta
$query_total = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM hasil");
$data_total = mysqli_fetch_assoc($query_total);
$total_peserta = $data_total['total'];

// Ambil nama-nama yang lulus (4 orang teratas)
$query_lulus = mysqli_query($koneksi, "SELECT nama FROM hasil 
                                       JOIN alternatif ON hasil.id_alternatif = alternatif.id_alternatif 
                                       WHERE keputusan = 'Lulus' 
                                       ORDER BY hasil.nilai DESC LIMIT 4");
$nama_lulus = [];
while ($row_lulus = mysqli_fetch_assoc($query_lulus)) {
    $nama_lulus[] = htmlspecialchars($row_lulus['nama']);
}

// Hitung jumlah lulus dan tidak lulus
$total_lulus = count($nama_lulus);
$total_tidak_lulus = $total_peserta - $total_lulus;

?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-chart-area"></i> Data Hasil Akhir</h1>
    <a href="cetak.php" target="_blank" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Hasil Akhir Perankingan</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <form method="post">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead class="bg-primary text-white">
                        <tr align="center">
                            <th>Nama</th>
                            <th>Nilai</th>
                            <th width="15%">Rank</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        $query = mysqli_query($koneksi, "SELECT * FROM hasil JOIN alternatif ON hasil.id_alternatif = alternatif.id_alternatif ORDER BY hasil.nilai DESC");
                        while ($data = mysqli_fetch_array($query)) {
                            $no++;
                        ?>
                            <tr align="center">
                                <td align="left"><?= htmlspecialchars($data['nama']); ?></td>
                                <td><?= htmlspecialchars($data['nilai']); ?></td>
                                <td><?= $no; ?></td>
                                <td>
                                    <select class="form-control" name="keputusan[<?= $data['id_alternatif']; ?>]" required>
                                        <option value="">--Belum Diputuskan--</option>
                                        <option value="Tidak Lulus" <?= $data['keputusan'] === 'Tidak Lulus' ? 'selected' : ''; ?>>Tidak Lulus</option>
                                        <option value="Lulus" <?= $data['keputusan'] === 'Lulus' ? 'selected' : ''; ?>>Lulus</option>
                                    </select>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
                <!-- <div class="text-center mt-3">
                    <button name="submit_all" value="submit_all" type="submit" class="btn btn-success">
                        <i class="fa fa-save"></i> Simpan Semua
                    </button>
                </div>
                <div class="text-center mt-2">
                    <p class="text-muted">
                        Calon Karyawan baru dengan nilai di atas 0,11 yang dinyatakan "Lulus": <strong><?= $jumlah_terbaik; ?> Orang</strong>
                    </p>
                    <p class="text-muted">
                        Nama-nama karyawan yang "Lulus": <strong><?= implode(', ', $nama_lulus); ?></strong>
                    </p>
                </div> -->
                <?php
// Hitung total peserta
$query_total = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM hasil");
$data_total = mysqli_fetch_assoc($query_total);
$total_peserta = $data_total['total'];

// Ambil nama-nama yang lulus (4 orang teratas)
$query_lulus = mysqli_query($koneksi, "SELECT nama FROM hasil 
                                       JOIN alternatif ON hasil.id_alternatif = alternatif.id_alternatif 
                                       WHERE keputusan = 'Lulus' 
                                       ORDER BY hasil.nilai DESC LIMIT 4");
$nama_lulus = [];
while ($row_lulus = mysqli_fetch_assoc($query_lulus)) {
    $nama_lulus[] = htmlspecialchars($row_lulus['nama']);
}

// Hitung jumlah lulus dan tidak lulus
$total_lulus = count($nama_lulus);
$total_tidak_lulus = $total_peserta - $total_lulus;
?>

<div class="mt-3">
    <p style="font-weight:bold;">
        Berdasarkan hasil perhitungan dan perangkingan akhir, 
        maka terdapat <span style="color:green;"><?= $total_lulus; ?> orang yang dinyatakan LULUS</span>, yaitu:
        <?= implode(", ", $nama_lulus); ?>.
        <br>
        Sedangkan jumlah peserta yang <span style="color:red;">tidak lulus</span> adalah 
        <?= $total_tidak_lulus; ?> orang.
    </p>
</div>


            </form>
        </div>
    </div>
</div>

<?php
    require_once('template/footer.php');
} else {
    header('Location: login.php');
    exit;
}
?>
