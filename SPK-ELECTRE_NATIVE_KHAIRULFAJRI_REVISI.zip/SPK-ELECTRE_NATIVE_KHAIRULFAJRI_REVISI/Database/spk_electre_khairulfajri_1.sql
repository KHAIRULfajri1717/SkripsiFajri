-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2025 at 02:08 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spk_electre_khairulfajri`
--

-- --------------------------------------------------------

--
-- Table structure for table `alternatif`
--

CREATE TABLE `alternatif` (
  `id_alternatif` int(11) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `nisn` varchar(30) NOT NULL,
  `kelas` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `alternatif`
--

INSERT INTO `alternatif` (`id_alternatif`, `nama`, `nisn`, `kelas`) VALUES
(101, 'MULKI HENDRI', '0084944308', 'XI.F.1'),
(102, 'NICKO LASMANA PRATAMA', '0087656629', 'XI.F.1'),
(103, 'MUHAMMAD SHADIQ', '0087810370', 'XI.F.1'),
(104, 'JUNI KARVINZA', '0082636314', 'XI.F.1'),
(105, 'NERA DESRIANTI', '0093696822', 'XI.F.1'),
(106, 'IKHSAN TAHER', '0098036846', 'XI.F.1'),
(107, 'HANIFA', '0061335484', 'XI.F.1'),
(108, 'BIMA OKTAFIANUS', '0089766871', 'XI.F.1'),
(109, 'DINDA RAHMA PARTIWI', '0097837358', 'XI.F.1'),
(110, 'WANGI VERONA', '0091769794', 'XI.F.1'),
(111, 'TANIA RAFLESIA', '0089373505', 'XI.F.2'),
(112, 'SOFI', '0063428236', 'XI.F.2'),
(113, 'TASYA RAHMADANI', '0077196353', 'XI.F.2'),
(114, 'VIOLA YULIANA', '0081095213', 'XI.F.2'),
(115, 'YOHANDI', '0068873088', 'XI.F.2'),
(116, 'RILA', '0076502309', 'XI.F.2'),
(117, 'REZKI SAPUTRA', '0077122049', 'XI.F.2'),
(118, 'RONALDO', '0068439795', 'XI.F.2'),
(119, 'RIMA CANTIKA', '0087075303', 'XI.F.2'),
(120, 'KAMAL YUSUF', '0068164298', 'XI.F.2');

-- --------------------------------------------------------

--
-- Table structure for table `hasil`
--

CREATE TABLE `hasil` (
  `id_hasil` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `nilai` float NOT NULL,
  `keputusan` enum('Tidak Lulus','Lulus') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `hasil`
--

INSERT INTO `hasil` (`id_hasil`, `id_alternatif`, `nilai`, `keputusan`) VALUES
(1, 111, 19, 'Tidak Lulus'),
(2, 112, 17.5429, 'Lulus'),
(3, 113, 15.5258, ''),
(4, 114, 15.5258, ''),
(5, 101, 11.108, ''),
(6, 102, 10.507, ''),
(7, 115, 7.1, ''),
(8, 116, 7.1, ''),
(9, 103, 6.62808, ''),
(10, 104, 6.62808, ''),
(11, 105, 1.39, ''),
(12, 117, 1.39, ''),
(13, 118, 1.39, ''),
(14, 119, 1.39, ''),
(15, 106, -4.72848, ''),
(16, 107, -5.15, ''),
(17, 108, -9.49, ''),
(18, 109, -9.49, ''),
(19, 110, -13.1742, ''),
(20, 120, -13.83, '');

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE `kriteria` (
  `id_kriteria` int(11) NOT NULL,
  `kode_kriteria` varchar(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `bobot` float NOT NULL,
  `ada_pilihan` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `kode_kriteria`, `nama`, `bobot`, `ada_pilihan`) VALUES
(12, 'K1', 'Nilai Matematika', 0.28, 1),
(13, 'K2', 'NIlai Fisika', 0.22, 1),
(14, 'K3', 'Nilai Biologi', 0.17, 1),
(15, 'K4', 'Nilai Kimia', 0.22, 1),
(16, 'K5', 'Nilai Rata Rata RAPOR', 0.11, 1);

-- --------------------------------------------------------

--
-- Table structure for table `penilaian`
--

CREATE TABLE `penilaian` (
  `id_penilaian` int(11) NOT NULL,
  `id_alternatif` int(10) NOT NULL,
  `id_kriteria` int(10) NOT NULL,
  `nilai` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `penilaian`
--

INSERT INTO `penilaian` (`id_penilaian`, `id_alternatif`, `id_kriteria`, `nilai`) VALUES
(293, 44, 12, 51),
(294, 44, 13, 58),
(295, 44, 14, 63),
(296, 44, 15, 32),
(297, 44, 16, 38),
(298, 45, 12, 51),
(299, 45, 13, 59),
(300, 45, 14, 62),
(301, 45, 15, 33),
(302, 45, 16, 37),
(303, 46, 12, 52),
(304, 46, 13, 56),
(305, 46, 14, 60),
(306, 46, 15, 33),
(307, 46, 16, 37),
(308, 47, 12, 51),
(309, 47, 13, 57),
(310, 47, 14, 61),
(311, 47, 15, 33),
(312, 47, 16, 38),
(313, 48, 12, 52),
(314, 48, 13, 58),
(315, 48, 14, 62),
(316, 48, 15, 33),
(317, 48, 16, 38),
(318, 50, 12, 53),
(319, 50, 13, 57),
(320, 50, 14, 62),
(321, 50, 15, 31),
(322, 50, 16, 39),
(323, 50, 12, 53),
(324, 50, 13, 57),
(325, 50, 14, 62),
(326, 50, 15, 31),
(327, 50, 16, 39),
(328, 51, 12, 53),
(329, 51, 13, 56),
(330, 51, 14, 60),
(331, 51, 15, 32),
(332, 51, 16, 39),
(333, 52, 12, 53),
(334, 52, 13, 59),
(335, 52, 14, 61),
(336, 52, 15, 33),
(337, 52, 16, 38),
(338, 53, 12, 52),
(339, 53, 13, 59),
(340, 53, 14, 62),
(341, 53, 15, 33),
(342, 53, 16, 40),
(343, 54, 12, 51),
(344, 54, 13, 59),
(345, 54, 14, 60),
(346, 54, 15, 33),
(347, 54, 16, 39),
(348, 55, 12, 51),
(349, 55, 13, 58),
(350, 55, 14, 62),
(351, 55, 15, 32),
(352, 55, 16, 36),
(353, 56, 12, 52),
(354, 56, 13, 58),
(355, 56, 14, 62),
(356, 56, 15, 31),
(357, 56, 16, 38),
(358, 57, 12, 51),
(359, 57, 13, 58),
(360, 57, 14, 60),
(361, 57, 15, 31),
(362, 57, 16, 37),
(363, 58, 12, 52),
(364, 58, 13, 59),
(365, 58, 14, 62),
(366, 58, 15, 32),
(367, 58, 16, 38),
(368, 59, 12, 52),
(369, 59, 13, 59),
(370, 59, 14, 63),
(371, 59, 15, 33),
(372, 59, 16, 37),
(373, 60, 12, 52),
(374, 60, 13, 58),
(375, 60, 14, 60),
(376, 60, 15, 33),
(377, 60, 16, 39),
(378, 61, 12, 54),
(379, 61, 13, 58),
(380, 61, 14, 62),
(381, 61, 15, 32),
(382, 61, 16, 40),
(383, 62, 12, 52),
(384, 62, 13, 57),
(385, 62, 14, 60),
(386, 62, 15, 33),
(387, 62, 16, 37),
(388, 63, 12, 54),
(389, 63, 13, 58),
(390, 63, 14, 63),
(391, 63, 15, 33),
(392, 63, 16, 38),
(393, 64, 12, 53),
(394, 64, 13, 57),
(395, 64, 14, 60),
(396, 64, 15, 32),
(397, 64, 16, 40),
(398, 65, 12, 52),
(399, 65, 13, 59),
(400, 65, 14, 62),
(401, 65, 15, 32),
(402, 65, 16, 38),
(403, 66, 12, 52),
(404, 66, 13, 59),
(405, 66, 14, 63),
(406, 66, 15, 33),
(407, 66, 16, 40),
(408, 67, 12, 52),
(409, 67, 13, 58),
(410, 67, 14, 60),
(411, 67, 15, 33),
(412, 67, 16, 37),
(413, 68, 12, 51),
(414, 68, 13, 58),
(415, 68, 14, 62),
(416, 68, 15, 32),
(417, 68, 16, 40),
(418, 69, 12, 52),
(419, 69, 13, 59),
(420, 69, 14, 60),
(421, 69, 15, 33),
(422, 69, 16, 38),
(423, 70, 12, 53),
(424, 70, 13, 59),
(425, 70, 14, 63),
(426, 70, 15, 33),
(427, 70, 16, 38),
(428, 71, 12, 52),
(429, 71, 13, 58),
(430, 71, 14, 63),
(431, 71, 15, 33),
(432, 71, 16, 36),
(433, 72, 12, 54),
(434, 72, 13, 56),
(435, 72, 14, 62),
(436, 72, 15, 33),
(437, 72, 16, 36),
(438, 73, 12, 53),
(439, 73, 13, 56),
(440, 73, 14, 60),
(441, 73, 15, 33),
(442, 73, 16, 38),
(443, 74, 12, 52),
(444, 74, 13, 58),
(445, 74, 14, 60),
(446, 74, 15, 32),
(447, 74, 16, 39),
(448, 75, 12, 52),
(449, 75, 13, 59),
(450, 75, 14, 63),
(451, 75, 15, 32),
(452, 75, 16, 39),
(453, 76, 12, 54),
(454, 76, 13, 57),
(455, 76, 14, 60),
(456, 76, 15, 32),
(457, 76, 16, 37),
(458, 77, 12, 54),
(459, 77, 13, 58),
(460, 77, 14, 62),
(461, 77, 15, 33),
(462, 77, 16, 37),
(463, 78, 12, 54),
(464, 78, 13, 56),
(465, 78, 14, 60),
(466, 78, 15, 32),
(467, 78, 16, 38),
(468, 79, 12, 51),
(469, 79, 13, 59),
(470, 79, 14, 62),
(471, 79, 15, 31),
(472, 79, 16, 40),
(473, 80, 12, 52),
(474, 80, 13, 58),
(475, 80, 14, 62),
(476, 80, 15, 31),
(477, 80, 16, 38),
(478, 81, 12, 54),
(479, 81, 13, 59),
(480, 81, 14, 62),
(481, 81, 15, 32),
(482, 81, 16, 39),
(483, 82, 12, 52),
(484, 82, 13, 57),
(485, 82, 14, 60),
(486, 82, 15, 33),
(487, 82, 16, 38),
(488, 83, 12, 52),
(489, 83, 13, 58),
(490, 83, 14, 63),
(491, 83, 15, 32),
(492, 83, 16, 39),
(493, 84, 12, 52),
(494, 84, 13, 59),
(495, 84, 14, 63),
(496, 84, 15, 32),
(497, 84, 16, 40),
(498, 85, 12, 52),
(499, 85, 13, 58),
(500, 85, 14, 62),
(501, 85, 15, 32),
(502, 85, 16, 37),
(503, 86, 12, 52),
(504, 86, 13, 58),
(505, 86, 14, 62),
(506, 86, 15, 33),
(507, 86, 16, 37),
(508, 87, 12, 54),
(509, 87, 13, 57),
(510, 87, 14, 60),
(511, 87, 15, 32),
(512, 87, 16, 38),
(513, 88, 12, 52),
(514, 88, 13, 58),
(515, 88, 14, 63),
(516, 88, 15, 31),
(517, 88, 16, 40),
(518, 89, 12, 52),
(519, 89, 13, 59),
(520, 89, 14, 60),
(521, 89, 15, 31),
(522, 89, 16, 38),
(703, 101, 12, 67),
(704, 101, 13, 72),
(705, 101, 14, 76),
(706, 101, 15, 82),
(707, 101, 16, 86),
(708, 102, 12, 67),
(709, 102, 13, 72),
(710, 102, 14, 77),
(711, 102, 15, 81),
(712, 102, 16, 87),
(713, 103, 12, 67),
(714, 103, 13, 71),
(715, 103, 14, 76),
(716, 103, 15, 81),
(717, 103, 16, 86),
(718, 104, 12, 67),
(719, 104, 13, 71),
(720, 104, 14, 76),
(721, 104, 15, 81),
(722, 104, 16, 86),
(723, 105, 12, 66),
(724, 105, 13, 71),
(725, 105, 14, 76),
(726, 105, 15, 81),
(727, 105, 16, 85),
(728, 106, 12, 66),
(729, 106, 13, 71),
(730, 106, 14, 75),
(731, 106, 15, 81),
(732, 106, 16, 85),
(733, 107, 12, 66),
(734, 107, 13, 70),
(735, 107, 14, 76),
(736, 107, 15, 81),
(737, 107, 16, 85),
(738, 108, 12, 66),
(739, 108, 13, 70),
(740, 108, 14, 75),
(741, 108, 15, 80),
(742, 108, 16, 85),
(743, 109, 12, 66),
(744, 109, 13, 70),
(745, 109, 14, 75),
(746, 109, 15, 80),
(747, 109, 16, 85),
(748, 110, 12, 66),
(749, 110, 13, 70),
(750, 110, 14, 75),
(751, 110, 15, 80),
(752, 110, 16, 84),
(753, 111, 12, 67),
(754, 111, 13, 72),
(755, 111, 14, 78),
(756, 111, 15, 83),
(757, 111, 16, 87),
(758, 112, 12, 67),
(759, 112, 13, 72),
(760, 112, 14, 78),
(761, 112, 15, 83),
(762, 112, 16, 86),
(763, 113, 12, 67),
(764, 113, 13, 72),
(765, 113, 14, 77),
(766, 113, 15, 82),
(767, 113, 16, 86),
(768, 114, 12, 67),
(769, 114, 13, 72),
(770, 114, 14, 77),
(771, 114, 15, 82),
(772, 114, 16, 86),
(773, 115, 12, 66),
(774, 115, 13, 72),
(775, 115, 14, 77),
(776, 115, 15, 82),
(777, 115, 16, 85),
(778, 116, 12, 66),
(779, 116, 13, 72),
(780, 116, 14, 77),
(781, 116, 15, 82),
(782, 116, 16, 85),
(783, 117, 12, 66),
(784, 117, 13, 71),
(785, 117, 14, 76),
(786, 117, 15, 81),
(787, 117, 16, 85),
(788, 118, 12, 66),
(789, 118, 13, 71),
(790, 118, 14, 76),
(791, 118, 15, 81),
(792, 118, 16, 85),
(793, 119, 12, 66),
(794, 119, 13, 71),
(795, 119, 14, 76),
(796, 119, 15, 81),
(797, 119, 16, 85),
(798, 120, 12, 66),
(799, 120, 13, 70),
(800, 120, 14, 74),
(801, 120, 15, 79),
(802, 120, 16, 85);

-- --------------------------------------------------------

--
-- Table structure for table `sub_kriteria`
--

CREATE TABLE `sub_kriteria` (
  `id_sub_kriteria` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `nilai` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sub_kriteria`
--

INSERT INTO `sub_kriteria` (`id_sub_kriteria`, `id_kriteria`, `nama`, `nilai`) VALUES
(64, 12, '<=65', 1),
(65, 12, '66-76', 2),
(66, 12, '77-83', 3),
(67, 12, '84-90', 4),
(68, 12, '>=91', 5),
(69, 13, '<=65', 1),
(70, 13, '66-76', 2),
(71, 13, '77-83', 3),
(72, 13, '84-90', 4),
(73, 13, '>=91', 5),
(74, 14, '<=65', 1),
(75, 14, '66-76', 2),
(76, 14, '77-83', 3),
(77, 14, '84-90', 4),
(78, 14, '>=91', 5),
(79, 15, '<=65', 1),
(80, 15, '66-76', 2),
(81, 15, '77-83', 3),
(82, 15, '84-90', 4),
(83, 15, '>=91', 5),
(84, 16, '<=75', 2),
(85, 16, '76-80', 3),
(86, 16, '81-85', 4),
(87, 16, '>=86', 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(5) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(70) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `role` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nama`, `email`, `role`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'ADMIN', 'admin@gmail.com', '1'),
(2, 'user', '12dea96fec20593566ab75692c9949596833adc9', 'siswa', 'user1@gmail.com', '2'),
(3, 'kepala sekolah', 'b662544d3fc7d4933a6d7bc935a6149275cf55f6', 'Kepala Sekolah', 'kepala@gmail.com', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id_alternatif`);

--
-- Indexes for table `hasil`
--
ALTER TABLE `hasil`
  ADD PRIMARY KEY (`id_hasil`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `penilaian`
--
ALTER TABLE `penilaian`
  ADD PRIMARY KEY (`id_penilaian`);

--
-- Indexes for table `sub_kriteria`
--
ALTER TABLE `sub_kriteria`
  ADD PRIMARY KEY (`id_sub_kriteria`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alternatif`
--
ALTER TABLE `alternatif`
  MODIFY `id_alternatif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `hasil`
--
ALTER TABLE `hasil`
  MODIFY `id_hasil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `id_kriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `penilaian`
--
ALTER TABLE `penilaian`
  MODIFY `id_penilaian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=803;

--
-- AUTO_INCREMENT for table `sub_kriteria`
--
ALTER TABLE `sub_kriteria`
  MODIFY `id_sub_kriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
