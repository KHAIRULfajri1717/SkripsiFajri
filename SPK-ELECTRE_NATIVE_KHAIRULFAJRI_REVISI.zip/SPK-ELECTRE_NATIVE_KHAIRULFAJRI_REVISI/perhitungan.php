<?php
require_once('includes/init.php');

$user_role = get_role();
if ($user_role == 'user' || $user_role == 'admin') {

    $page = "Perhitungan";
    require_once('template/header.php');

    // Truncate table 'hasil' and handle errors
    if (!mysqli_query($koneksi, "TRUNCATE TABLE hasil;")) {
        echo "Error truncating table: " . mysqli_error($koneksi);
    }

    // Fetch Kriteria
    $kriterias = array();
    $q0 = mysqli_query($koneksi, "SELECT SUM(bobot) as total FROM kriteria");
    $total_b = mysqli_fetch_array($q0);
    $q1 = mysqli_query($koneksi, "SELECT * FROM kriteria ORDER BY kode_kriteria ASC");
    while ($krit = mysqli_fetch_array($q1)) {
        $kriterias[$krit['id_kriteria']] = array(
            'id_kriteria' => $krit['id_kriteria'],
            'kode_kriteria' => $krit['kode_kriteria'],
            'nama' => $krit['nama'],
            'bobot' => $krit['bobot'],
            'ada_pilihan' => $krit['ada_pilihan'],
            'normalisasi' => $krit['bobot']
        );
    }

    // Fetch Alternatif
    $alternatifs = array();
    $q2 = mysqli_query($koneksi, "SELECT * FROM alternatif");
    while ($alt = mysqli_fetch_array($q2)) {
        $alternatifs[$alt['id_alternatif']] = array(
            'id_alternatif' => $alt['id_alternatif'],
            'nama' => $alt['nama']
        );
    }

    // Matriks Keputusan (X)
    $matriks_x = array();
    foreach ($kriterias as $kriteria) {
        foreach ($alternatifs as $alternatif) {
            $id_alternatif = $alternatif['id_alternatif'];
            $id_kriteria = $kriteria['id_kriteria'];
            if ($kriteria['ada_pilihan'] == 1) {
                $q4 = mysqli_query($koneksi, "SELECT sub_kriteria.nilai
                                              FROM penilaian
                                              JOIN sub_kriteria ON penilaian.nilai = sub_kriteria.id_sub_kriteria
                                              WHERE penilaian.id_alternatif = '$id_alternatif'
                                              AND penilaian.id_kriteria = '$id_kriteria'");
                $data = mysqli_fetch_array($q4);
                $nilai = $data['nilai'];
            } else {
                $q4 = mysqli_query($koneksi, "SELECT nilai
                                              FROM penilaian
                                              WHERE id_alternatif = '$id_alternatif'
                                              AND id_kriteria = '$id_kriteria'");
                $data = mysqli_fetch_array($q4);
                $nilai = $data['nilai'];
            }
            $matriks_x[$id_kriteria][$id_alternatif] = $nilai;
        }
    }

    // Akar Sigma
    $akar_sigma = array();
    foreach ($kriterias as $kriteria) {
        $id_kriteria = $kriteria['id_kriteria'];
        $total_kuadrat = 0;

        foreach ($alternatifs as $alternatif) {
            $id_alternatif = $alternatif['id_alternatif'];
            $nilai = $matriks_x[$id_kriteria][$id_alternatif];
            $total_kuadrat += pow($nilai, 2);
        }
		

        $akar_sigma[$id_kriteria] = sqrt($total_kuadrat);
    }

 // Matriks Normalisasi
$matriks_normalisasi = array();
foreach ($kriterias as $kriteria) {
    $id_kriteria = $kriteria['id_kriteria'];
    foreach ($alternatifs as $alternatif) {
        $id_alternatif = $alternatif['id_alternatif'];
        if ($akar_sigma[$id_kriteria] != 0) {
            $matriks_normalisasi[$id_kriteria][$id_alternatif] = 
                $matriks_x[$id_kriteria][$id_alternatif] / $akar_sigma[$id_kriteria];
        } else {
            $matriks_normalisasi[$id_kriteria][$id_alternatif] = 0; // Atau nilai default lain
        }
    }
}

// Matriks Normalisasi Terbobot
$matriks_normalisasi_terbobot = array();
foreach ($kriterias as $kriteria) {
    $id_kriteria = $kriteria['id_kriteria'];
    foreach ($alternatifs as $alternatif) {
        $id_alternatif = $alternatif['id_alternatif'];
        $matriks_normalisasi_terbobot[$id_kriteria][$id_alternatif] =
            $matriks_normalisasi[$id_kriteria][$id_alternatif] * $kriteria['normalisasi'];
    }
}

$concordance = array();
foreach ($alternatifs as $i => $alt_i) {
    foreach ($alternatifs as $j => $alt_j) {
        if ($i != $j) {
            $C_ij = array();
            $total_weight = 0;
            
            foreach ($kriterias as $id_kriteria => $kriteria) {
                if (
                    isset($matriks_normalisasi_terbobot[$id_kriteria][$alt_i['id_alternatif']]) &&
                    isset($matriks_normalisasi_terbobot[$id_kriteria][$alt_j['id_alternatif']]) &&
                    $matriks_normalisasi_terbobot[$id_kriteria][$alt_i['id_alternatif']] >=
                    $matriks_normalisasi_terbobot[$id_kriteria][$alt_j['id_alternatif']]
                ) {
                    $C_ij[] = $kriteria['kode_kriteria'];
                    $total_weight += $kriteria['bobot'];
                }
            }
            $concordance[$alt_i['id_alternatif']][$alt_j['id_alternatif']] = [
                'himpunan' => $C_ij,
                'total_weight' => $total_weight
            ];
        }
    }
}

$discordance = array();
foreach ($alternatifs as $i => $alt_i) {
    foreach ($alternatifs as $j => $alt_j) {
        if ($i != $j) {
            $D_ij = array();
            foreach ($kriterias as $id_kriteria => $kriteria) {
                if (
                    isset($matriks_normalisasi_terbobot[$id_kriteria][$alt_i['id_alternatif']]) &&
                    isset($matriks_normalisasi_terbobot[$id_kriteria][$alt_j['id_alternatif']]) &&
                    $matriks_normalisasi_terbobot[$id_kriteria][$alt_i['id_alternatif']] <
                    $matriks_normalisasi_terbobot[$id_kriteria][$alt_j['id_alternatif']]
                ) {
                    $D_ij[] = $kriteria['kode_kriteria'];
                }
            }
            $discordance[$alt_i['id_alternatif']][$alt_j['id_alternatif']] = $D_ij;
        }
    }
}

$totalDiscordance = array();
foreach ($alternatifs as $k => $alt_k) {
    foreach ($alternatifs as $l => $alt_l) {
        if ($k != $l) {
            $maxNumerator = 0;
            $maxDenominator = 0;

            foreach ($kriterias as $id_kriteria => $kriteria) {
                if (
                    isset($matriks_normalisasi_terbobot[$id_kriteria][$alt_k['id_alternatif']]) &&
                    isset($matriks_normalisasi_terbobot[$id_kriteria][$alt_l['id_alternatif']])
                ) {
                    $diff = abs(
                        $matriks_normalisasi_terbobot[$id_kriteria][$alt_k['id_alternatif']] -
                        $matriks_normalisasi_terbobot[$id_kriteria][$alt_l['id_alternatif']]
                    );
                    
                    $maxDenominator = max($maxDenominator, $diff);
                    
                    if (
                        $matriks_normalisasi_terbobot[$id_kriteria][$alt_k['id_alternatif']] <
                        $matriks_normalisasi_terbobot[$id_kriteria][$alt_l['id_alternatif']]
                    ) {
                        $maxNumerator = max($maxNumerator, $diff);
                    }
                }
            }

            $d_kl = ($maxDenominator != 0) ? ($maxNumerator / $maxDenominator) : 0;
            $totalDiscordance[$alt_k['id_alternatif']][$alt_l['id_alternatif']] = $d_kl;
        } else {
            $totalDiscordance[$alt_k['id_alternatif']][$alt_l['id_alternatif']] = '-';
        }
    }
}

$final_rank = array();
$offset = 0.0001; // nilai kecil untuk membedakan jika sama
foreach ($alternatifs as $i => $alt_i) {
    $total_dominance = 0;
    foreach ($alternatifs as $j => $alt_j) {
        if ($i != $j) {
            $concordance_value = isset($concordance[$alt_i['id_alternatif']][$alt_j['id_alternatif']]['total_weight'])
                ? $concordance[$alt_i['id_alternatif']][$alt_j['id_alternatif']]['total_weight']
                : 0;
            $discordance_value = isset($totalDiscordance[$alt_i['id_alternatif']][$alt_j['id_alternatif']]) && is_numeric($totalDiscordance[$alt_i['id_alternatif']][$alt_j['id_alternatif']])
                ? $totalDiscordance[$alt_i['id_alternatif']][$alt_j['id_alternatif']]
                : 0;

            $dominance = $concordance_value - $discordance_value;
            $total_dominance += $dominance;
        }
    }
    
    // tambahkan offset berdasarkan index alternatif
    $final_rank[$i] = [
        'nama' => $alt_i['nama'],
        'total_dominance' => $total_dominance + ($i * $offset)
    ];
}


// Sort alternatives by total dominance in descending order
usort($final_rank, function($a, $b) {
    return $b['total_dominance'] <=> $a['total_dominance'];
});

// Optional: Save ranking results to database
// $delete_query = "DELETE FROM hasil";
// mysqli_query($koneksi, $delete_query);

// foreach ($final_rank as $rank => $data) {
//     $nama = $data['nama'];
//     $total_dominansi = $data['total_dominance'];
//     $peringkat = $rank + 1;
    
//     $insert_query = "INSERT INTO hasil (nama, total_dominansi, peringkat) VALUES ('$nama', '$total_dominansi', '$peringkat')";
//     mysqli_query($koneksi, $insert_query);
// }

?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-calculator"></i> Data Perhitungan</h1>
</div>



<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Data Alternatif</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead class="bg-primary text-white">
                    <tr align="center">
                        <th width="5%" rowspan="2">No</th>
                        <th>Nama Alternatif</th>
                        <?php foreach ($kriterias as $kriteria): ?>
                            <th><?= $kriteria['kode_kriteria'] ?></th>
                        <?php endforeach ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $no = 1 ; 
                        foreach ($alternatifs as $alternatif): ?>
                    <tr align="center">
                        <td><?= $no; ?></td>
                        <td align="left"><?= $alternatif['nama'] ?></td>
                        <?php foreach ($kriterias as $kriteria): 
                            $id_alternatif = $alternatif['id_alternatif'];
                            $id_kriteria = $kriteria['id_kriteria'];
                        ?>
                            <td>
                                <?= $matriks_x[$id_kriteria][$id_alternatif] ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php 
                        $no++;
                        endforeach;
                    ?>
                    <!-- Tambahkan baris Akar Sigma -->
                    <tr align="center" class="bg-light">
                        <td colspan="2"><b>Akar Sigma</b></td>
                        <?php foreach ($kriterias as $kriteria): 
                            $id_kriteria = $kriteria['id_kriteria'];
                        ?>
                            <td>
                               <?= round($akar_sigma[$id_kriteria], 4) ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="card shadow mb-4">
    <!-- Card Header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Data Normalisasi Matriks Keputusan</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <!-- Table Header -->
                <thead class="bg-primary text-white">
                    <tr align="center">
                        <th width="5%">No</th>
                        <th>Nama Alternatif</th>
                        <?php foreach ($kriterias as $kriteria): ?>
                            <th><?= $kriteria['kode_kriteria'] ?></th>
                        <?php endforeach ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $no = 1;
                        foreach ($alternatifs as $alternatif): ?>
                            <tr align="center">
                                <td><?= $no; ?></td>
                                <td align="left"><?= $alternatif['nama'] ?></td>
                                <?php foreach ($kriterias as $kriteria): 
                                    $id_kriteria = $kriteria['id_kriteria'];
                                    $id_alternatif = $alternatif['id_alternatif'];
                                ?>
                                    <td>
                                        <?= round($matriks_normalisasi[$id_kriteria][$id_alternatif], 4); ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                    <?php 
                        $no++;
                        endforeach;
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Bobot Kriteria</h6>
    </div>

    <div class="card-body">
		<div class="table-responsive">
			<table class="table table-bordered" width="100%" cellspacing="0">
				<thead class="bg-primary text-white">
					<tr align="center">
						<?php foreach ($kriterias as $kriteria): ?>
						<th><?= $kriteria['kode_kriteria'] ?></th>
						<?php endforeach ?>
					</tr>
				</thead>
				<tbody>
					<tr align="center">
						<?php 
						
						foreach ($kriterias as $kriteria): ?>
						<td>
						<?php 
						echo $kriteria['normalisasi'];
						?>
						</td>
						<?php endforeach ?>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>

<div class="card shadow mb-4">
    <!-- Card Header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Nilai Normalisasi Terbobot</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <!-- Table Header -->
                <thead class="bg-primary text-white">
                    <tr align="center">
                        <th width="5%">No</th>
                        <th>Nama Alternatif</th>
                        <?php foreach ($kriterias as $kriteria): ?>
                            <th><?= $kriteria['kode_kriteria'] ?></th>
                        <?php endforeach ?>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $no = 1;
                        foreach ($alternatifs as $alternatif): ?>
                            <tr align="center">
                                <td><?= $no; ?></td>
                                <td align="left"><?= $alternatif['nama'] ?></td>
                                <?php foreach ($kriterias as $kriteria): 
                                    $id_kriteria = $kriteria['id_kriteria'];
                                    $id_alternatif = $alternatif['id_alternatif'];
                                ?>
                                    <td>
                                        <?= round($matriks_normalisasi_terbobot[$id_kriteria][$id_alternatif], 4); ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                    <?php 
                        $no++;
                        endforeach;
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="card shadow mb-4">
    <!-- Card Header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Himpunan Concordance Dan Matriks Concordance </h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <!-- Table Header -->
                <thead class="bg-primary text-white">
                    <tr align="center">
                        <th>Alternatif (i)</th>
                        <th>Alternatif (j)</th>
                        <th>Himpunan Concordance (C<sub>ij</sub>)</th>
                        <th>Total Matriks Concordance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($concordance as $id_i => $row): ?>
                        <?php foreach ($row as $id_j => $C_ij_data): ?>
                            <tr align="center">
                                <td><?= $alternatifs[$id_i]['nama']; ?></td>
                                <td><?= $alternatifs[$id_j]['nama']; ?></td>
                                <td>{ <?= implode(', ', $C_ij_data['himpunan']); ?> }</td>
                                <td><?= $C_ij_data['total_weight']; ?></td> <!-- Show total weight -->
                            </tr>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <!-- Card Header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Himpunan Discordance Dan Matriks Discordance</h6>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <!-- Table Header -->
                <thead class="bg-primary text-white">
                    <tr align="center">
                        <th>Alternatif (i)</th>
                        <th>Alternatif (j)</th>
                        <th>Himpunan Discordance (D<sub>ij</sub>)</th>
                        <th>Total Matriks Discordance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($discordance as $id_i => $row): ?>
                        <?php foreach ($row as $id_j => $D_ij): ?>
                            <tr align="center">
                                <td><?= $alternatifs[$id_i]['nama']; ?></td>
                                <td><?= $alternatifs[$id_j]['nama']; ?></td>
                                <td>{ <?= implode(', ', $D_ij); ?> }</td>
                                <td>
                                    <?php
                                        // Ensure that data for the matrix is displayed properly
                                        $nama_i = isset($alternatifs[$id_i]['nama']) ? $alternatifs[$id_i]['nama'] : 'Tidak Diketahui';
                                        $nama_j = isset($alternatifs[$id_j]['nama']) ? $alternatifs[$id_j]['nama'] : 'Tidak Diketahui';
                                        // Displaying the value from Discordance matrix
                                        echo (is_numeric($totalDiscordance[$id_i][$id_j]) ? number_format($totalDiscordance[$id_i][$id_j], 4) : 'N/A');
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php
// Clear existing data in the 'hasil' table
$delete_query = "DELETE FROM hasil";
mysqli_query($koneksi, $delete_query);

// Insert new ranking data into the database
$rank = 1;
foreach ($final_rank as $data) {
    $nama = $data['nama'];
    $total_dominansi = $data['total_dominance'];
    
    $insert_query = "
        INSERT INTO hasil (id_hasil, id_alternatif, nilai, keputusan)
        VALUES (
            NULL, 
            (SELECT id_alternatif FROM alternatif WHERE nama = '$nama'), 
            '$total_dominansi', 
            '$rank'
        )
    ";
    $result = mysqli_query($koneksi, $insert_query);
    if (!$result) {
        die("Error inserting data: " . mysqli_error($koneksi));
    }
    $rank++;
}
?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-trophy"></i> Perangkingan Akhir</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead class="bg-primary text-white">
                    <tr align="center">
                        <th>Peringkat</th>
                        <th>Nama Alternatif</th>
                        <th>Total Dominansi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($final_rank as $rank => $data): ?>
                    <tr align="center">
                        <td><?= $rank + 1 ?></td>
                        <td><?= $data['nama'] ?></td>
                        <td><?= number_format($data['total_dominance'], 4) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php
            // Ambil 4 terbaik
            $lulus = array_slice($final_rank, 0, 4);
            $nama_lulus = array_column($lulus, 'nama');
            
            // Hitung total alternatif
            $total_alt = count($final_rank);
            
            // Hitung jumlah tidak lulus
            $tidak_lulus = $total_alt - 4;
            ?>
            
            <p style="margin-top:20px; font-weight:bold;">
                Berdasarkan hasil perhitungan dan perangkingan akhir, 
                maka terdapat <span style="color:green;">4 orang yang dinyatakan LULUS</span>, yaitu:
                <?= implode(", ", $nama_lulus); ?>.
                <br>
                Sedangkan jumlah peserta yang <span style="color:red;">tidak lulus</span> adalah 
                <?= $tidak_lulus; ?> orang.
            </p>            
        </div>
    </div>
</div>

<?php
require_once('template/footer.php');
}
else {
	header('Location: login.php');
}
?>